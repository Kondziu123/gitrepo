/*
 * hello.cpp
 
 */


#include <iostream>

using namespace std;

int main (int argc, char **argv)
{
    
    int bok = 0; // deklaracja ai inicjacja zmiennej
    cout <<"Podaj bok: " ;
    cin >> bok;
    cout <<"obwód: " << 4 * bok << endl
    <<"Pole: "  << bok * bok << endl;
    
    
    
    
	return 0;
}

