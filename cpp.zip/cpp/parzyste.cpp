/*
 * parzyste.cpp 
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	int a;
    cout << "Podaj wartość liczby a: ";
    cin >> a;
    for(int a = 0)
	return 0;
}

