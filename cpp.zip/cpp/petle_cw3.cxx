/*
 * petle_cw3.cxx
 
 */


#include <iostream>

int main(int argc, char **argv)
{
	
	return 0;
}

