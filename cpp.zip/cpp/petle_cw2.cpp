/*
 * petle_cw2.cpp

 */


#include <iostream>
using namespace std 

int main(int argc, char **argv)
{
	
    for (int n=1; m=10; i++)
    cout << " " <<n<<" ";
	return 0;
}

