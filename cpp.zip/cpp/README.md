Moje repozytorium do pracy na lekcjach informatyki
