/*
 * Sewera_alg1.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	int a;
    cout << "Podaj wartość liczby a: ";
    for(int i = 1; i < 100; i ++);
        i = 2;
        if( a = i);
            cout <<"Liczba jest parzysta";
        else;
            i = i + 2;
    return 0;
}

